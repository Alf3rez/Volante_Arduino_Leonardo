#include "Arduino.h"
#include "UwUKeypad.h"

UwUKeypad::UwUKeypad(byte COL1, byte COL2, byte COL3, byte COL4, byte FIL1, byte FIL2, byte FIL3, byte FIL4){
    this->OUTS[0] = FIL1;
    pinMode(FIL1, OUTPUT);
    digitalWrite(FIL1, HIGH);
    this->OUTS[1] = FIL2;
    pinMode(FIL2, OUTPUT);
    digitalWrite(FIL2, HIGH);
    this->OUTS[2] = FIL3;
    pinMode(FIL3, OUTPUT);
    digitalWrite(FIL3, HIGH);
    this->OUTS[3] = FIL4;
    pinMode(FIL4, OUTPUT);
    digitalWrite(FIL4, HIGH);

    this->INS[0] = COL1;
    pinMode(COL1, INPUT_PULLUP);
    this->INS[1] = COL2;
    pinMode(COL2, INPUT_PULLUP);
    this->INS[2] = COL3;
    pinMode(COL3, INPUT_PULLUP);
    this->INS[3] = COL4;
    pinMode(COL4, INPUT_PULLUP);
}

UwUKeypad::~UwUKeypad(){
    delete[] pressedKeys;
}

void UwUKeypad::getKeysState(bool* keys){
    this->scanKeys();
    for(byte i = 0; i < 16; i++){
        keys[i] = this->pressedKeys[i];
    }
}

char UwUKeypad::getPressed(){
    this->scanKeys();
    for(byte i = 0; i < 16; i++){
        if(this->pressedKeys[i] == 0){
            return this->keyMap[i];
        }
    }
    return keyMap[17];
}

byte UwUKeypad::getPressedPos(){
    this->scanKeys();
    for(byte i = 0; i < 16; i++){
        if(this->pressedKeys[i] == 0){
            return i;
        }
    }
    return 255;
}

void UwUKeypad::scanKeys(){
    byte out,in;
    for(out = 0; out < 4; out++){
        digitalWrite(this->OUTS[out], LOW);
        for(in = 0; in < 4; in++){
            pressedKeys[(out*4)+in] = digitalRead(INS[in]);
        }
        digitalWrite(this->OUTS[out], HIGH);
    }
}

byte UwUKeypad::setKeyMap(char* newKeyMap){
    if(sizeof(newKeyMap) == 17){
        for(byte i = 0; i < 17; i++){
            this->keyMap[i] = newKeyMap[i];
        }
        return 0;
    }
    return 1;
}
char* UwUKeypad::getKeyMap(){}