#include "Arduino.h"
#ifndef _UWU_KEYPAD_
#define _UWU_KEYPAD_

class UwUKeypad{
private:
    byte INS[4];
    byte OUTS[4];
    bool pressedKeys[16];
    char keyMap[17] = {'1', '2', '3', 'A', '4', '5', '6', 'B', '7', '8', '9', 'C', '*', '0', '#', 'D', 0x00};
    void scanKeys();
public:
    UwUKeypad(byte COL1, byte COL2, byte COL3, byte COL4, byte FIL1, byte FIL2, byte FIL3, byte FIL4);
    ~UwUKeypad();
    void getKeysState(bool* keys);
    char getPressed();
    byte getPressedPos();

    byte setKeyMap(char* newKeyMap);
    char* getKeyMap();
};

#endif